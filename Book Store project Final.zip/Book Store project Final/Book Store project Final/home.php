<?php

include 'config.php';
session_start();

if(isset($_POST['add_to_cart'])){
   if(isset($_SESSION['user_id']))
   {
      $user_id = $_SESSION['user_id'];
      $product_name = $_POST['product_name'];
      $product_price = $_POST['product_price'];
      $product_image = $_POST['product_image'];
      $product_quantity = $_POST['product_quantity'];

      $check_cart_numbers = "SELECT * FROM cart WHERE user_id = '$user_id' AND name = '$product_name'";
      $result = $conn->query($check_cart_numbers);
      if($result->num_rows>0)
      {
         $message[] = "Product already added!";
      }
      else{
         $cart_insert = "INSERT INTO cart (user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')";
         $result_insert = $conn->query($cart_insert);
         if($result_insert === TRUE)
         {
            $message[] = "Product added successfully";
         }
         else{
            $message[] = "Failed to add the product";
         }
      }
   }

   else
   {
      $message[] = 'Please <a href="login.php">Login</a> First!' ;
   }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">
   
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
   
<?php include 'header.php'; ?>

<section class="home">

   <div class="content">
      <h3>Hand Picked Book to your door.</h3>
      <p>If you are a student or someone interested in reading books, Booklify has great deals on a wide range of books. Shop for these books from top authors and avail hugely discounted prices</p>
      <a href="about.php" class="white-btn">Discover more</a>
   </div>

</section>

<section class="products">

   <h1 class="title">latest products</h1>

   <!-- <input type="text" placeholder = "Search Products" id = "Search"> -->

   <div class="box-container">
      <?php
         include "config.php";
         $select_query = "SELECT * FROM products order by id DESC limit 3";
         $result_select_query = $conn->query($select_query);
         if($result_select_query->num_rows>0)
         {
            while($row = mysqli_fetch_array($result_select_query))
            {
               echo "<form action='' method='post' class='box'>
                     <img class='image' src='images/" . $row['image'] . "' alt=''>
                     <div class='name'>" . $row['name'] . "</div>
                     <div class='price'>$" . $row['price'] . "</div>
                     <input type='number' min='1' name='product_quantity' value='1' class='qty'>
                     <input type='hidden' name='product_name' value='" . $row['name'] . "'>
                     <input type='hidden' name='product_price' value='" . $row['price'] . "'>
                     <input type='hidden' name='product_image' value='" . $row['image'] . "'>
                     <input type='submit' value='add to cart' name='add_to_cart' class='btn'>
                  </form>";
               
            }
         }
         else{
            echo "<p>No products added!</p>";
         }
      ?>
   </div>

   <div class="load-more" style="margin-top: 2rem; text-align:center">
      <a href="shop.php" class="option-btn">load more</a>
   </div>

</section>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about.jpg" width="300px" alt="">
      </div>

      <div class="content">
         <h3>about us</h3>
         <p>We committed to providing you with the best shopping experience. We're here to answer your questions and guide you through our diverse range of products.</p>
         <a href="about.php" class="btn">See more</a>
      </div>

   </div>

</section>

<section class="home-contact">

   <div class="content">
      <h3>have any questions?</h3>
      <p>If you have questions or just want to get in touch, contact us via email or phone number. We look to hearing you from everywhere</p>
      <a href="contact.php" class="white-btn">contact us</a>
   </div>

</section>


<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>