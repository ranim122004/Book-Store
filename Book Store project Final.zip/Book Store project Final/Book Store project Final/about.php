<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">
   <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>


</head>

<body>

   <?php
   session_start();
   include 'header.php'; ?>

   <div class="heading">
      <h3>about us</h3>
   </div>
   <section id="contact-details" class="section-p1">
        <div class="details">
            <span>GET IN TOUCH</span>
            <h2>Visit one of our agency location or contact us today</h2>
            <h3>Head Office</h3>
            <div>
                <li>
                    <i class="fal fa-map"></i>
                    <p>Barja, Maabour street</p>
                </li>
                <li>
                    <i class="fal fa-envelope"></i>
                    <p>Booklify@gmail.com</p>
                </li>
                <li>
                    <i class="fal fa-phone-alt"></i>
                    <p>+961 03 641 404</p>
                </li>
                <li>
                    <i class="fal fa-clock"></i>
                    <p>Monday to Saturday: 8:00am to 9:00pm</p>
                </li>
            </div>
        </div>
        <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26570.459715989182!2d35.42286761895451!3d33.6491943171293!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151ee39af6e4e421%3A0xd69f9387e579f368!2sBarja!5e0!3m2!1sen!2slb!4v1711659758910!5m2!1sen!2slb" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>
   <section class="about">

      <div class="flex">

         <div class="image">
            <img src="images/about-img.jpg" alt="">
         </div>

         <div class="content">
            <h3>why choose us?</h3>
            <p>In Booklify, we believe that books should enrich your life. Whether you're a literature enthusiast, a professional, or someone exploring the world of books, we have something for you, for sure.</p>
            <p>Our mission is to foster a love of reading and learning in our community, providing an accessible platform where readers can discover new stories, broaden their horizons, and connect with fellow book enthusiasts</p>
            <a href="contact.php" class="btn">contact us</a>
         </div>



      </div>
   <div class="marquee">

<marquee bgcolor="#ccc" loop="-1" scrollamount="5" width="48.75%" >Fall - Winter - Spring - Summer We Are Next
             To You! With Pleasure To Serve </marquee>
</div>
   </section>
   <div class="video-container">
   <h1>Visit Our Shop</h1>
        <h3>To Get The Full Experience</h3>
   <video autoplay muted loop src="video.mp4"></video>

   </div>
   



   <!-- <section class="authors">

      <h1 class="title">Meet Our Team</h1>

      <div class="box-container">

         <div class="box">
             
            <div class="share">
               <a href="https://www.facebook.com/" class="fa-brands fa-facebook"></a>
               <a href="https://twitter.com/i/flow/login" class="fa-brands fa-x-twitter"></a>
               <a href="https://www.instagram.com/" class="fa-brands fa-instagram"></a>
               <a href="https://www.linkedin.com/" class="fa-brands fa-linkedin"></a>
            </div>
            <h3>Ali Fakhreddine</h3>
            <h2>Junior CS Student</h2>
         </div>

         <div class="box">
           
            <div class="share">
               <a href="https://www.facebook.com/" class="fa-brands fa-facebook"></a>
               <a href="https://twitter.com/i/flow/login" class="fa-brands fa-x-twitter"></a>
               <a href="https://www.instagram.com/" class="fa-brands fa-instagram"></a>
               <a href="https://www.linkedin.com/" class="fa-brands fa-linkedin"></a>
            </div>
            <h3>Raneem Al Zarif</h3>
            <h2>Junior CS Student</h2>
         </div>

         <div class="box">
           
            <div class="share">
               <a href="https://www.facebook.com/" class="fa-brands fa-facebook"></a>
               <a href="https://twitter.com/i/flow/login" class="fa-brands fa-x-twitter"></a>
               <a href="https://www.instagram.com/" class="fa-brands fa-instagram"></a>
               <a href="https://www.linkedin.com/" class="fa-brands fa-linkedin"></a>
            </div>
            <h3>Rami Saifan</h3>
            <h2>Junior CS Student</h2>
         </div>

      </div>

   </section> -->







   <?php include 'footer.php'; ?>

   <!-- custom js file link  -->
   <script src="js/script.js"></script>

</body>

</html>