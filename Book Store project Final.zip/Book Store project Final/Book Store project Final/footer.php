<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>Quick links</h3>
         <a href="home.php">Home</a>
         <a href="about.php">About</a>
         <a href="shop.php">Shop</a>
         <a href="contact.php">Contact</a>
      </div>

      <div class="box">
         <h3>Extra links</h3>
         <a href="login.php">Login</a>
         <a href="register.php">Register</a>
         <?php
            if(isset($_SESSION["user_id"]))
            {
               echo "<a href='cart.php'>cart</a>";
               echo" <a href='orders.php'>Orders</a>";
            }
         ?>
        
      </div>

      <div class="box">
         <h3>Contact info</h3>
         <p> <i class="fas fa-phone"></i> 81 / 905703 </p>
         <p> <i class="fas fa-phone"></i>  03 / 641404 </p>
         <p> <i class="fas fa-envelope"></i> Booklify@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Barja , Lebanon - 4004104 </p>
      </div> 

      

      <div class="box social">
         <h3>Follow us</h3>
         <nav>
         <a href="https://www.facebook.com/" target = "_blank"> <i class="fab fa-facebook-f"></i>  </a>
         <a href="https://twitter.com/i/flow/login" target = "_blank"> <i class="fab fa-twitter"></i>  </a>
         <a href="https://www.instagram.com/" target = "_blank"> <i class="fab fa-instagram"></i>  </a>
         <a href="https://www.linkedin.com/" target = "_blank"> <i class="fab fa-linkedin"></i>  </a>
         </nav>
         <p>Secured Payment Gateways</p>
            <img src="images/pay.png" alt="">
      </div>

    
       
   </div>

    <p class="credit"> &copy;   Booklify@gmail.com <?php echo date( "Y");?> </p>


</section>

