



<?php
if(!isset($_POST['Login'])) { 
    $message[]="Login first Or  <a href='home.php'>Enter as Guest</a> ?"  ;
 }
   include 'config.php';
   session_start();

   if (isset($_POST['Login'])) 
   {

      $email = $_POST['email'];
      $pass = $_POST['password'];

      $select_users = "SELECT * FROM users WHERE email = '$email'";
      $result = $conn->query($select_users);

      if($result->num_rows > 0) {

         if (isset($_POST["check"])){
            $expire = time() + 60 * 60 * 24 * 7; 
            setcookie("Email", $email, $expire);

         }

         else{
            setcookie("Email", "", time() - 3600);
         }

         $row = mysqli_fetch_assoc($result);

         if($row['user_type'] == 'admin'){

            $VerifyPass = password_verify($pass, $row["password"]);

            if ($VerifyPass === TRUE) {
               $_SESSION['admin_name'] = $row['name'];
               $_SESSION['admin_email'] = $row['email'];
               $_SESSION['admin_id'] = $row['id'];
               header('location:admin_page.php');

            }

            else{
               $message[] = 'incorrect password!';
            }

      } 
      else if($row['user_type'] == 'user'){

            $VerifyPass = password_verify($pass, $row["password"]);

            if ($VerifyPass === TRUE) {
                $_SESSION['user_name'] = $row['name'];
                $_SESSION['user_email'] = $row['email'];
                $_SESSION['user_id'] = $row['id'];
                header('location:home.php');

            }

            else{
                $message[] = 'incorrect password!';
            }
        }

      } 

      else{
         $message[] = 'incorrect email or password!';
      }
   }

if (isset($_COOKIE['Email'])) {
    $preFilledEmail = $_COOKIE['Email'];
} else {
    $preFilledEmail = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>
<body>

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>
   
   <div class="form-container">

<form action="" method="post">
    <h3>login now</h3>
    <input type="email" name="email" placeholder="Enter your email" required class="box" value="<?php echo $preFilledEmail; ?>">
    <input type="password" name="password" placeholder="Enter your password" required class="box">

    <div class="checkbox-container">
      <label class="checkbox-btn">
         <label for="checkbox"></label>
         <input id="checkbox" type="checkbox" name = "check">
         <span class="checkmark"></span>
      </label>

      <label id = "check-label" for="checkbox">Remember Me</label>
   </div>
    <input type="submit" name="Login" value="Login" class="btn">

    <p>don't have an account? <a href="register.php">Register now</a></p>
</form>

</div>

</body>
</html>