<?php
include "config.php";

session_start();

$user_id = $_SESSION["user_id"];

if(isset($_GET["delete_id"])){
    $total = 0;
    $itemId = $_GET["delete_id"];
    $deleteCartQuery = "DELETE FROM cart WHERE id = '$itemId' AND user_id = '$user_id'";
    $result = $conn->query($deleteCartQuery);
    if($result){
        $selectCartQuery = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'");
        if(mysqli_num_rows($selectCartQuery) > 0) {
            $cartItemsHTML = ''; 
            while($fetch_cart = mysqli_fetch_assoc($selectCartQuery)){
        
                $total += ($fetch_cart['price'] * $fetch_cart['quantity']);
                
                
                $cartItemsHTML .= "<div class='box'>";
                $cartItemsHTML .= "<a href='cart.php?delete_id=" . $fetch_cart['id'] . "' class='delete-item fas fa-times'></a>";
                $cartItemsHTML .= "<img src='uploaded_img/" . $fetch_cart['image'] . "' alt=''>";
                $cartItemsHTML .= "<div class='name'>" . $fetch_cart['name'] . "</div>";
                $cartItemsHTML .= "<div class='price'>$" . $fetch_cart['price'] . "</div>";
                $cartItemsHTML .= "<form action='' method='post'>";
                $cartItemsHTML .= "<input type='hidden' name='id' value='" . $fetch_cart['id'] . "'>";
                $cartItemsHTML .= "<input type='number' min='1' name='qty' value='" . $fetch_cart['quantity'] . "'>";
                $cartItemsHTML .= "<input type='submit' name='Update' value='update' class='option-btn'>";
                $cartItemsHTML .= "</form>";
                $cartItemsHTML .= "</div>";
            }
        } else {
            $cartItemsHTML = '<p class="empty">Your cart is empty</p>';
        }
        
        
        $response = array(
            'html' => $cartItemsHTML, 
            'total_price' => $total
        );
        echo json_encode($response); 
    }
}
?>
