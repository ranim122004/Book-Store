$(document).ready(function() {
   $('#menu-btn').click(function() {
       $('.header .navbar').toggleClass('active');
       $('.header .account-box').removeClass('active');
   });

   $('#user-btn').click(function() {
       $('.header .account-box').toggleClass('active');
       $('.header .navbar').removeClass('active');
   });

   $(window).scroll(function() {
       $('.header .navbar').removeClass('active');
       $('.header .account-box').removeClass('active');
   });

   $('#close-update').click(function() {
       $('.edit-product-form').hide();
       window.location.href = 'admin_products.php';
   });
});