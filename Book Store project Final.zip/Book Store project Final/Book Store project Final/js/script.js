$(document).ready(function () {
  let userBox = $(".header .header-2 .user-box");
  let navbar = $(".header .header-2 .navbar");

  $(document)
    .off("click", "#user-btn")
    .on("click", "#user-btn", function (event) {
      console.log("user-btn");
      userBox.toggleClass("active");
      navbar.removeClass("active");
    });

  $(document)
    .off("click", "#menu-btn")
    .on("click", "#menu-btn", function (event) {
      event.preventDefault();
      navbar.toggleClass("active");
      userBox.removeClass("active");
    });

  $(window).scroll(function () {
    userBox.removeClass("active");
    navbar.removeClass("active");

    if ($(window).scrollTop() > 60) {
      $(".header .header-2").addClass("active");
    } else {
      $(".header .header-2").removeClass("active");
    }
  });

  //search
  $("#Search").on("input", function () {
    let searchTerm = $(this).val().trim();
    searchProducts(searchTerm);
  });

  function searchProducts(value) {
    let productContainer = $(".box-container form");
    let productName = $(".box-container form .name");

    productContainer.each(function (index) {
      if (
        $(productName[index])
          .text()
          .trim()
          .toUpperCase()
          .includes(value.toUpperCase())
      ) {
        $(this).show();
      } else {
        $(this).hide();
      }
    });
  }

  if (window.location.hash === "#SearchProducts") {
    $("#search-btn").hide();
    $("#Search").focus();
  }
  $("#search-icon").click(function () {
    $("#Search").focus();
  });

  $(document)
    .off("click", ".delete-item")
    .on("click", ".delete-item", function (e) {
      e.preventDefault();

      let itemId = $(this).attr("href").split("=")[1];
      let deletedItemContainer = $(this).closest(".box");

      if (confirm("Are you sure you want to delete this item from the cart?")) {
        $.ajax({
          type: "GET",
          url: "delete_item.php",
          data: { delete_id: itemId },
          dataType: "json",
          success: function (response) {
            deletedItemContainer.remove(); 
            var totalPrice = parseFloat(response.total_price);
            $(".cart-total span").text("$" + totalPrice);

            if (totalPrice === 0) {
              $(".shopping-cart .delete-btn").hide();
              $(".shopping-cart .btn").hide();
            } else {
              $(".shopping-cart .checkout-btn").show();
              $(".shopping-cart .btn").show();
            }
          },
          error: function (error) {
            console.log("Error Fetching: " + error);
          },
        });
      }
    });
});
