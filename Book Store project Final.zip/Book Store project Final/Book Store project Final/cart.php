<?php
include "config.php";

session_start();

$user_id = $_SESSION["user_id"];
if(isset($_POST["Update"])){

   $Quantity = $_POST["qty"];
   $cart_id = $_POST["id"];

   $check_Updated_Quantity = "SELECT quantity FROM cart WHERE id = '$cart_id'";
   $result_check_Updated_Quantity = $conn->query($check_Updated_Quantity);

   if($result_check_Updated_Quantity->num_rows > 0)
   {
      $cart_quantity = mysqli_fetch_array($result_check_Updated_Quantity);
      if($cart_quantity["quantity"] === $Quantity){
         $message[] = "Quantity already exists, No need to update!";
      }
      else{
         $insert_Updated_Quantity = "UPDATE cart SET quantity = '$Quantity' WHERE id = '$cart_id'";
         $result_insert_Updated_Quantity = $conn->query($insert_Updated_Quantity);
         if($result_insert_Updated_Quantity === TRUE)
         {
            $message[] = "cart quantity updated &#x2713";
         }
         else{
            $message[] = "Can't update cart quantity!";
         }
      }
   }
}

if(isset($_GET["delete_id"])){
   $cart_id = $_GET["delete_id"];
   $delete_cart = "DELETE FROM cart WHERE id = '$cart_id '";
   $result_delete_cart = $conn->query($delete_cart);
   if($result_delete_cart === TRUE){
      $message[] = "Product removed successfully &#x2713";
   }
   else{
      $message[] = "Can't remove the Product from cart!";
   }
}

if(isset($_GET["delete_all"]))

{
   $delete_all = $_GET["delete_all"];
   $Clear_cart = "DELETE FROM cart WHERE user_id = '$user_id'";
   $result_Clear_cart = $conn->query($Clear_cart);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>cart</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>Shopping cart</h3>
   
</div>

<section class="shopping-cart">

   <h1 class="title">products added</h1>

   <div class="box-container">
      <?php
         $grand_total = 0;
         $select_cart = mysqli_query($conn, "SELECT * FROM cart WHERE user_id = '$user_id'") or die('query failed');
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){   
      ?>
      <div class="box">
         <a href="cart.php?delete_id=<?php echo $fetch_cart['id']; ?>" class="delete-item fas fa-times"></a>

         <img src="images/<?php echo $fetch_cart['image']; ?>" alt="">
         <div class="name"><?php echo $fetch_cart['name']; ?></div>
         <div class="price">$<?php echo $fetch_cart['price']; ?></div>
         <form action="" method="post">
            <input type="hidden" name="id" value="<?php echo $fetch_cart['id']; ?>">
            <input type="number" min="1" name="qty" value="<?php echo $fetch_cart['quantity']; ?>">
            <input type="submit" name="Update" value="update" class="option-btn">
         </form>
      </div>
      <?php
      $grand_total += ($fetch_cart['quantity'] * $fetch_cart['price']);
         }
      }else{
         echo '<p class="empty">your cart is empty</p>';
      }
      ?>
   </div>

   <div style="margin-top: 2rem; text-align:center;">
    <?php
        if($grand_total > 0){
            echo "<a href='cart.php?delete_all' class='delete-btn' onclick=\"return confirm('delete all from cart?');\">delete all</a>";
        }
    ?>
</div>


   <div class="cart-total">
      <?php
         echo "<p> Total : <span>$" . $grand_total . "</span></p>";
      ?>
      <div class='flex'>
         <a href='shop.php' class='option-btn' >Continue shopping</a>
         <?php
            if($grand_total > 0){
               echo "<a href='checkout.php' class='btn'>Proceed to checkout</a>";
            }
         ?>
      </div>
   </div>

</section>









<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
</body>
</html>