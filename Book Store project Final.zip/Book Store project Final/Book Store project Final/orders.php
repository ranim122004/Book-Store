<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>orders</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>
<body>
   
<?php session_start(); include "header.php"; ?>

<div class="heading">
   <h3>Your orders</h3>
</div>

<section class="placed-orders">

   <h1 class="title">placed orders</h1>

   <div class="box-container">

      <?php
         include "config.php";
         if(isset($_SESSION['user_id'])){
            $user_id = $_SESSION['user_id'];
            $order_query = "SELECT * FROM orders WHERE user_id = '$user_id'";
            $result_order_query = $conn->query($order_query);
            if($result_order_query -> num_rows > 0)
            {
               while($row = mysqli_fetch_assoc($result_order_query))
               {
                  echo '<div class="box">
                     <p> Placed on: <span>' . $row['placed_on'] . '</span> </p>
                     <p> Name: <span>' . $row['name'] . '</span> </p>
                     <p> Number: <span>' . $row['number'] . '</span> </p>
                     <p> Email: <span>' . $row['email'] . '</span> </p>
                     <p> Address: <span>' . $row['address'] . '</span> </p>
                     <p> Payment method: <span>' . $row['method'] . '</span> </p>
                     <p> Your orders: <span>' . $row['total_products'] . '</span> </p>
                     <p> Total price: <span>$' . $row['total_price'] . '</span> </p>
                     <p> Payment status: <span style="color:' . ($row['payment_status'] == 'pending' ? 'red' : 'green') . ';">' . $row['payment_status'] . '</span> </p>
                  </div>';
               }
            }
            else
            {
               echo '<p class="empty">No orders placed yet!</p>';
            }
         }
         else
         {
            echo '<p class="empty">No orders placed yet!</p>';
         }   
      ?>
   </div>

</section>

<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>