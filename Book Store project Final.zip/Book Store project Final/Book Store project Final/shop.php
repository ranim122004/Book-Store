<?php

include 'config.php';

session_start();

if(isset($_POST["add_to_cart"]))
{
   if(isset($_SESSION["user_id"]))
   {
      $user_id = $_SESSION["user_id"];

      $product_name = $_POST["product_name"];
      $product_price = $_POST["product_price"];
      $product_image = $_POST["product_image"];
      $product_quantity = $_POST["product_quantity"];

      $select_cart = "SELECT * FROM cart WHERE user_id = '$user_id' AND name = '$product_name'";
      $result_select_cart = $conn->query($select_cart);
      if($result_select_cart->num_rows>0)
      {
         $message[] = "Product already added to cart!";
      }
      else{
         $insert_cart = "INSERT INTO cart (user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')";
         $result_insert_cart = $conn->query($insert_cart);
         if($result_insert_cart === TRUE)
         {
            $message[] = "Product added to cart";
         }
         else{
            $message[] = "Failed to add to the cart!";
         }
      }
   }
   else{
      $message[] = "Please <a href = 'login.php'> Login First";
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>shop</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>


</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>our shop</h3>
   <!-- <p> <a href="home.php">home</a> / shop </p> -->
</div>

<section class="products">

   <h1 class="title">latest products</h1>
   <!-- search input -->
   <div class="search">
   <input type="text" placeholder = "Search.." id = "Search" >
   <button id = "search-icon" style = "cursor:pointer">
   <i class="fa-solid fa-magnifying-glass"></i>
   </button>
   
   </div>
   

   <div class="box-container">

      <?php  
         include "config.php";
         $select_products = "SELECT * FROM products";
         $result_select_products = $conn->query($select_products);
         if ($result_select_products->num_rows > 0) {
             while ($row = mysqli_fetch_array($result_select_products)) {
                 echo '<form action="" method="post" class="box">';
                 echo '<img class="image" src="images/' . $row['image'] . '" alt="">';
                 echo '<div class="name">' . $row['name'] . '</div>';
                 echo '<div class="price">$' . $row['price'] . '</div>';
                 echo '<input type="number" min="1" name="product_quantity" value="1" class="qty">';
                 echo '<input type="hidden" name="product_name" value="' . mysqli_real_escape_string($conn, $row['name']) . '">';
                 echo '<input type="hidden" name="product_price" value="' . $row['price'] . '">';
                 echo '<input type="hidden" name="product_image" value="' . $row['image'] . '">';
                 echo '<input type="submit" value="add to cart" name="add_to_cart" class="btn">';
                 echo '</form>';
             }
         }
         else{
            echo '<p class="empty">no products added yet!</p>';
         }
      ?>
   </div>

</section>








<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>