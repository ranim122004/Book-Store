<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/style1.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>

<body>
<header class="header">
<?php

   if(!isset($_SESSION["user_id"])){
      echo "<div class='header-1'>
         <p><a href='login.php'>login</a> | <a href='register.php'>register</a> </p>
      </div>";
   }
?>


<div class="header-2">
  
   <div class="flex">
  
   <div class="logos">
   <a href="home.php"><img src="images/logo.png" alt="" id="logo" width="60px" /></a>
      <a href="home.php" class="logo">Booklify</a>
   </div>

   <nav class="navbar">
         <a href="home.php">Home</a>
         <!-- <a href="orders.php">Orders</a> -->
         <a href="about.php">About</a>
         <a href="shop.php">Shop</a>
         <a href="contact.php">Contact</a>
      </nav>

      <div class="icons">
         
      <div id="menu-btn" class="fas fa-bars"></div>
         <?php
         if(isset($_SESSION["user_id"]))
         {
            echo "<a href='shop.php#SearchProducts'><div id='search-btn' class='fas fa-search'></div></a>";
            include "config.php";
            $user_id = $_SESSION["user_id"];
            $select_cart_number = "SELECT * FROM cart WHERE user_id = '$user_id'";
            $resultSelect = $conn->query($select_cart_number);
            $cart_rows_number = $resultSelect->num_rows;

            echo "<div id='user-btn' class='fas fa-user'></div>";
         
            echo "<a href='cart.php'> <i class='fas fa-shopping-cart'></i> <span>" . $cart_rows_number . "</span> </a>";     
         }
         
         ?>
      </div>

      <div class="user-box">
         <?php
            if(isset($_SESSION['user_id'])) 
            {
               echo "<p>Username : <span>" . $_SESSION['user_name'] . "</span></p>";
               echo "<p>Email : <span>" . $_SESSION['user_email'] . "</span></p>";
               echo "<a href = 'orders.php' class = 'option-btn' style = 'margin-bottom:10px'>Your Orders</a><br>";
               echo "<a href='logout.php' class='delete-btn'>Logout</a>";
            } 
            else
            {
               echo "<a href='login.php' class='login-btn'>login</a>";
            }
           
         ?>
      </div>
   </div>
</div>

</header>

<script src="js/script.js"></script>
</body>
</html>