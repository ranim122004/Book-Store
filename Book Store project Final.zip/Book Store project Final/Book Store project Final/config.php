<?php

$conn = new mysqli('localhost','root','','bookshop') or die('connection failed');

$name = "Admin";
$email = "Admin@gmail.com";
$password = "Admin123";
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "SELECT * FROM users WHERE  email='".$email."'";

$result = $conn->query($sql);
if(!$result->num_rows > 0){
    $conn->query( "INSERT INTO users(name, email, password, user_type) VALUES ('$name' , '$email', '$hashed_password' , 'admin')");
    //insert the user into the database
}
?>
