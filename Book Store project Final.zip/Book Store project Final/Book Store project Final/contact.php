<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['send'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $msg = mysqli_real_escape_string($conn, $_POST['message']);

   $select_message = mysqli_query($conn, "SELECT * FROM `message` WHERE name = '$name' AND email = '$email' AND number = '$number' AND message = '$msg'") or die('query failed');

   if(mysqli_num_rows($select_message) > 0){
      $message[] = 'message sent already!';
   }else{
      mysqli_query($conn, "INSERT INTO `message`(user_id, name, email, number, message) VALUES('$user_id', '$name', '$email', '$number', '$msg')") or die('query failed');
      $message[] = 'message sent successfully!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>contact</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>contact us</h3>
   
</div>

<section id="form-details">
        <form id="contactForm" action="" method="post">
            <span>LEAVE A MESSAGE</span>
            <h2>We love to hear from you</h2>
            <input name="name" id="Name" type="text" placeholder="Your Name" required>
            <input name="email" id="Email" type="text" placeholder="E-mail" required >
            <input   name="number"  id="Message" type="number" placeholder="Number" required autocomplete="off">
            <textarea name="message" id="MessageContent" cols="30" rows="10" placeholder="Your Message" required autocomplete="off"></textarea>
            <input name="send" class="normal" id="subbtn" type="submit" value="submit">
          </form>
        
     

        <div class="people">
         <div>
            <img src="images/Rami.png" alt="" >
            <p><span>Rami Saaifan</span> Junior CS Student <br> +961 3 641 404 <br> Email: Rami@gmail.com</p>
         </div>  
         <div>
         <img src="images/Ali.png"  alt="">
            <p><span>Ali Fakhreddine</span> Junior CS Student <br> +961 81 905 703 <br> Email: Ali@gmail.com</p>
         </div>  
         <div>
            <img src="images/ranim.jpg"  alt="">
            <p><span>Raneem Al-Zarif </span>  Junior CS Student <br> +961 76 963 249 <br> Email: Raneem@gmail.com</p>
         </div>  
        </div>
    </section>








<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>