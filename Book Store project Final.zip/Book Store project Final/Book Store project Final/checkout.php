<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['order_btn'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $number = $_POST['number'];
   $email = $_POST['email']; 
   $method = $_POST['method'];
   $address = $_POST['flat'].', '. $_POST['street'].', '. $_POST['city'].', '. $_POST['country'].' - '. $_POST['pin_code'];
   $placed_on = date('d-M-Y');

   $cart_total = 0;
   $cart_products = array(); 

   $cart_query = "SELECT * FROM cart WHERE user_id = '$user_id'";
   $result_cart_query = $conn->query($cart_query);

   if ($result_cart_query->num_rows > 0) {
      while ($row = mysqli_fetch_assoc($result_cart_query)) {
        $cart_products[] = $row["name"] . "(" . $row["quantity"]  . ")";
        $cart_total += $row["price"] * $row["quantity"];
      }
   }
   else{
      $message[] = 'Your Cart is empty';
   }

   $total_products = implode(', ', $cart_products);

   $order_query = "SELECT * FROM orders WHERE user_id = '$user_id' AND name = '$name' AND number = '$number' AND email = '$email' AND method = '$method' AND address = '$address' AND total_products = \"$total_products\" AND total_price = '$cart_total'";
   $result_order_query = $conn->query($order_query);

   
   if($result_order_query->num_rows>0)
   {
      $message[] = 'order already placed!';
   }
   else
   {
      $order_query_insert = "INSERT INTO orders (user_id, name , number, email, method, address, total_products, total_price, placed_on) VALUES('$user_id', '$name' , '$number', '$email', '$method', '$address', \"$total_products\", '$cart_total', '$placed_on')";

      $result_order_query_insert = $conn->query($order_query_insert);

      if($result_order_query_insert === TRUE)
      {
         mysqli_query($conn, "DELETE FROM cart WHERE user_id = '$user_id'") or die('query failed');
         $message[] = 'Thanks for buying from Booklify &#x263A <a href = "orders.php">Your Orders</a>';

      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>checkout</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style1.css">

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>checkout</h3>
</div>

<section class="display-order">
   <h2>Your Orders</h2>
   <?php  
   include "config.php";
      $total = 0;
      $select_cart = "SELECT * FROM cart WHERE user_id = '$user_id'";
      $result = $conn->query($select_cart);
      if($result->num_rows>0)
      {
         while($row = mysqli_fetch_assoc($result)){
            $total_price = ($row['price'] * $row['quantity']);

            echo "<p>" . $row['name'] . " <span>($" . $row['price'] . " /x " . $row['quantity'] . ")</span></p>";

            $total += $total_price;
         }
      }
      else{
         echo '<p class="empty">Your cart is empty</p>';
      }
   ?>
 
   <div class="grand-total">Total : <span>$<?php echo $total; ?></span> </div>

</section>

<section class="checkout">

   <form action="" method="post">
      <h3>Place Your Order</h3>
      <div class="flex">
         <div class="inputBox">
            <span>Your Name :</span>
            <input type="text" name="name" required>
         </div>
         <div class="inputBox">
            <span>Your Phone Number :</span>
            <input type="number" name="number" required >
         </div>
         <div class="inputBox">
            <span>Your Email :</span>
            <input type="email" name="email" required >
         </div>
         <div class="inputBox">
            <span>Payment Method :</span>
            <select name="method">
               <option value="cash on delivery">cash on delivery</option>
               <option value="credit card">credit card</option>
               <option value="paypal">paypal</option>
               <option value="paytm">paytm</option>
            </select>
         </div>
         <div class="inputBox">
            <span>Address line 01 :</span>
            <input type="number" min="0" name="flat" required placeholder="e.g. flat no.">
         </div>
         <div class="inputBox">
            <span><Area></Area>Address line 02 :</span>
            <input type="text" name="street" required placeholder="e.g. street name">
         </div>
         <div class="inputBox">
            <span>City :</span>
            <input type="text" name="city" required placeholder="e.g. Beirut">
         </div>
         <div class="inputBox">
            <span>State :</span>
            <input type="text" name="state" required placeholder="e.g. Hamrah">
         </div>
         <div class="inputBox">
            <span>Country :</span>
            <input type="text" name="country" required placeholder="e.g. Lebanon">
         </div>
         <div class="inputBox">
            <span>Pin Code :</span>
            <input type="number" min="0" name="pin_code" required placeholder="e.g. 123456">
         </div>
      </div>
      <input type="submit" value="Order" class="btn" name="order_btn">
   </form>

</section>

<?php include 'footer.php'; ?>

<!-- custom js file link  -->

<script src="js/script.js"></script>

</body>
</html>